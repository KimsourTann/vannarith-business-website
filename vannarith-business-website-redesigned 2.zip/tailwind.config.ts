import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // "brand" = Pine — the deep pharmacy green that anchors the mark,
        // standing in for the green cross used on dispensaries everywhere.
        brand: {
          50: "#EEF5F1",
          100: "#D3E7DC",
          200: "#A8CFBA",
          300: "#74B196",
          400: "#3D8E71",
          500: "#1F7A5C",
          600: "#166348",
          700: "#124F3A",
          800: "#0F3E2E",
          900: "#0B2E22",
        },
        // "gold" = Clay — a brick-capsule rust, the warm half of a
        // two-tone pill, used sparingly for calls to action.
        gold: {
          50: "#FBEDE6",
          100: "#F3D2C0",
          300: "#E2A47B",
          400: "#D3814E",
          500: "#BC5F2E",
          600: "#9B4A22",
        },
        // "sand" = Paper — a cool, clinical off-white (a label stock,
        // not a warm cream) that the rest of the palette sits on.
        sand: {
          50: "#F8F7F2",
          100: "#F1EFE6",
          200: "#E2DED1",
        },
        ink: "#17251F",
      },
      fontFamily: {
        display: ["var(--font-display)"],
        sans: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      letterSpacing: {
        widest2: "0.28em",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "gradient-conic":
          "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
        "circuit-dots": "radial-gradient(currentColor 1px, transparent 1px)",
      },
      backgroundSize: {
        "circuit-dots": "22px 22px",
      },
      boxShadow: {
        card: "0 1px 2px rgba(15,62,46,0.08), 0 8px 24px -8px rgba(15,62,46,0.18)",
        panel: "0 20px 60px -20px rgba(15,62,46,0.38)",
      },
      borderRadius: {
        xl: "0.85rem",
      },
      transitionTimingFunction: {
        // gentle "ease-out-expo" style curve used across hover / reveal
        // animations so motion feels fluid rather than mechanical
        smooth: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      animation: {
        "pop-in": "popIn 320ms cubic-bezier(0.22, 1, 0.36, 1)",
        "fade-up": "fadeUp 700ms cubic-bezier(0.22, 1, 0.36, 1) both",
        "fade-in": "fadeIn 250ms ease-out both",
      },
      keyframes: {
        popIn: {
          "0%": {
            transform: "scale(0.92)",
            opacity: "0",
          },
          "100%": {
            transform: "scale(1)",
            opacity: "1",
          },
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
