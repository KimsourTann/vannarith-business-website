import type { Metadata } from "next";
import { Petrona, Work_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { Footer, Header } from "@/components";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Petrona: a book-ish, apothecary-label serif with a bit of ink-trap
// character in its curves — carries the page's personality.
const petrona = Petrona({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  variable: "--font-display",
});

// Work Sans: quiet, clinical, highly legible workhorse for body copy.
const workSans = Work_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
});

export const metadata: Metadata = {
  title: "PE-SUPPLY Co.,LTD",
  description:
    "Our primary customers include healthcare professionals, fitness enthusiasts, and tech-They seek reliable health solutions and the latest technology to enhance their lives.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${workSans.variable} ${petrona.variable} ${plexMono.variable} grid grid-rows-[auto,1fr] font-sans`}
      >
        <Header />
        <div className="relative flex min-h-full flex-col">
          {children}
          <Footer />
        </div>
        <ToastContainer />
      </body>
    </html>
  );
}
